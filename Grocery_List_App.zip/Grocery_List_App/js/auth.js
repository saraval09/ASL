// expose our config directly to our application using module.exports
module.exports = {

    'facebookAuth' : {
        'clientID'      : '1086111638101440', // your App ID
        'clientSecret'  : '25d34bb385884253f50d5ac7f3791ae5', // your App Secret
        'callbackURL'   : 'http://localhost:3306/auth/facebook/callback'}

};